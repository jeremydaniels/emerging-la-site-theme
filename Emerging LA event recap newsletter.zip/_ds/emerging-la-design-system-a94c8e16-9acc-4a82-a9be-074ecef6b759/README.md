# Emerging LA — Design System

A documentation-first design system for **Emerging LA**, built entirely from the attached
specification (`uploads/ela-design-system-spec.md`). It documents a cream-ground editorial
system with one anchor orange, three typefaces, and a photo frame as its signature object.

## Sources given

- `uploads/ela-design-system-spec.md` — the component specification. **Ground truth.** All
  values in this system come from it verbatim; nothing was rounded or snapped to a grid.
- `uploads/Riegal.woff` — the display face, supplied by the user. One weight, 400.
- Eight mobile screenshots of the live site (`uploads/Screenshot_20260819_*.jpg`) — used as
  visual reference for texture and how parts sit together only. No copy and no layout was
  taken from them, per the brief.
- Manrope and Courier Prime load from Google Fonts.

No codebase and no Figma file were provided. There is therefore no UI kit in this project:
the brief explicitly forbids pages, navigation, heroes, footers and arrangements of
components, so every component is documented alone on a blank ground instead.

## Read this first — the non-negotiables

- **Three typefaces only.** Riegal (display), Manrope (body), Courier Prime (mono labels and
  metadata). There is no fourth face.
- **Riegal has one weight, 400.** No bold, no synthetic bold, no `font-stretch`. Set
  `font-synthesis: none`. Hierarchy comes from size, tracking, line-height and case only.
- **Orange is never body copy in light mode.** All three orange values fail contrast on cream.
- **Exactly one anchor-orange element is live at a time**, and orange stays under roughly 10%
  of visible area. Hairline orange is exempt: the 26px eyebrow rule, the 2px date-block left
  border, an arrow glyph.
- **Cream is the ground.** Orange is never a default background.
- **Photos always run monochrome.**
- **There is no emblem, icon, symbol, monogram or arrow mark in this brand and there never
  will be.** The logo is a wordmark only. Do not create one, do not add one to a component,
  do not add one to a favicon.
- **Border radius is 2px or 0. Nothing else.** Photo frames, wells and table rows are 0.
  Buttons, cards, chips and inputs are 2px.
- **Do not round half-step spacing** (10.5px, 14.5px, 1.5px). They are load bearing.

## Index

| File | What it is |
| --- | --- |
| `documentation.html` | The whole system as documentation, with a complete side menu — one entry per card. Start here. |
| `styles.css` | The single entry point consumers link. `@import` lines only. |
| `tokens/` | `fonts`, `colors`, `typography`, `spacing`, `borders`, `shadows`, `motion`, `surfaces`. |
| `guidelines/` | 21 foundation cards — 10 colour, 11 type. |
| `components/` | 10 component families, each with `.jsx`, `.d.ts`, `.prompt.md` and a documentation card. |
| `assets/fonts/Riegal.woff` | The display face. |
| `thumbnail.html` | The homepage tile. |
| `SKILL.md` | Agent-skill entry point. |

## Components

Ten families, exactly the inventory the specification defines. Nothing was added.

| Component | Directory | Notes |
| --- | --- | --- |
| `PhotoFrame` | `components/photo-frame/` | Mat, well, mono bar — always all three. Four crop marks or none. |
| `MonoBar` | `components/mono-bar/` | Top strip on ink, photo bar on ground, legal bar. |
| `SectionHeader` | `components/section-header/` | Numbered eyebrow, display-5 heading, 1px rule. |
| `Card` | `components/card/` | The one card treatment; frame plus body. |
| `RuledTable` | `components/table/` | Mono header, hairline rows, wash hover, radius 0. |
| `Button` | `components/button/` | primary, primarySmall, secondary, inkSubmit, quietLink. |
| `Toggle`, `ToggleGroup` | `components/toggle/` | Mono segmented control; group owns the border. |
| `RoleChip`, `CategoryChip` | `components/chip/` | Selectable mono chip; solid orange card-well label. |
| `Input` | `components/input/` | Underline only, Courier Prime 17px value. |
| `Surface` | `components/surface/` | `on-ink`, `on-accent`, `on-paper` token re-pointing. |

**Intentional additions:** none. **Deliberate omissions:** no logo mark (the brand is a
wordmark only, and none was supplied — render "Emerging LA" in Riegal wherever a mark would
go); no photography (wells are shown empty); no icon set (see Iconography).

## Content fundamentals

The brief is unusually strict here: **the system ships placeholder copy and nothing else.**
Use these strings and do not write new ones.

| Slot | String |
| --- | --- |
| Display heading | `HEADLINE GOES HERE` |
| Sentence-case title | `Sentence case card headline goes here` |
| Eyebrow | `NN · SECTION LABEL` |
| Mono meta | `LABEL · LABEL · LABEL` |
| Body | standard lorem ipsum |
| Button | `Button label` |
| Photo caption | `PLATE NN · LOCATION / TIME` |

Casing is the live rule, not the words: **if it is a sentence somebody would read aloud, it
is sentence case** — card headlines, table row titles, full-sentence statements. Everything
else is uppercase — display headings, section headings, and every mono label, eyebrow, tab
and metadata item. Mono is uppercase everywhere except an input value, which is the one
place mono runs mixed case.

Separators are middots (`·`), never em dashes. Directional text is `Read →` and must be
paired with a non-orange sibling label in the same row. No emoji anywhere. No exclamation
marks. No first or second person, because there is no voice copy in the system at all —
labels are nouns, not sentences.

## Visual foundations

**Ground and surfaces.** Cream `#F5F0EB` is the 60; `#FFFDFA` paper is the raised surface;
ink `#1C1C1C` carries every word. Orange `#FF6218` is an anchor, never a background. A block
that changes ground re-points tokens once via `.on-ink` / `.on-accent` / `.on-paper` so
children keep writing `var(--ink)` and `var(--rule)`.

**Type.** Riegal for display and titles at one weight; Manrope 400-700 for body and UI;
Courier Prime for all structure. Display steps are fluid with both ends real (display-1 is
46px at 375px, 124px at desktop). Tight line-heights (0.86-0.95) work because Riegal's
x-height is 545/1000. The mono tracking ladder is closed: 0.10, 0.12, 0.13, 0.14, 0.16,
0.18, 0.20 — smaller type gets wider tracking, and 0.16em is the workhorse.

**Spacing.** Base unit 2px with half-steps expected (10.5px, 14.5px, 1.5px) and never
rounded. Content max 1360px, gutters 30px → 18px, section top padding 82px → 54px, card grid
gap 26px → 16px. One breakpoint only: 900px.

**Backgrounds.** Flat colour. No gradients of any kind, no repeating patterns, no textures,
no illustration. The only "image" treatment in the system is a monochrome photograph inside
a dark well `#15130F`, framed by a paper mat with four 16px cream crop marks inset 14px.
Full-bleed happens exactly twice: the mono top strip on ink, and one orange section band per
layout.

**Borders and rules.** Depth is drawn with lines, not shadows. 1px rule for section headers,
card borders and table headers; 1px hairline inside lists and cards; 1.5px edge for input
underlines; 1.5px cream for crop marks; 2px accent for date-block and active left borders.
**Hover borders go to full ink — the line gets darker, never thicker.**

**Corner radii.** 2px on buttons, cards, chips and inputs. 0 on photo frames, wells and
table rows. There is no third value.

**Cards.** Paper ground, 1px rule border, radius 2px, asymmetric `12px 12px 0` padding
because the metadata bar supplies the bottom. Body `16px 4px 18px`. Hairline divider above
the mono meta row.

**Shadows.** Three, all far-throw with heavy negative spread, never tight:
card `0 22px 40px -34px rgba(28,28,28,0.70)`, panel `0 40px 70px -50px rgba(28,28,28,0.60)`,
hero `0 1px 0 rgba(28,28,28,0.04), 0 40px 70px -60px rgba(28,28,28,0.85)`. Suppressed
entirely in dark mode.

**Animation.** Almost none. 0.15s ease on chips and toggles, 0.2s ease on cards, and that is
the whole motion system. No bounce, no spring, no entrance animation, no parallax, no
scroll-triggered reveals.

**Hover states.** Colour and border only. Primary orange lightens to `#FF8426`; secondary
fills ink with paper text; ink submit turns orange; card border goes to ink and gains the
card shadow; table rows fill wash `rgba(28,28,28,0.035)`. **No transform, no scale, no
lift** — a card gets more present, it does not move.

**Press and focus.** There is no separate press treatment; the hover state holds.
Focus-visible is a 2px accent outline at 2px offset everywhere except inputs, where the
1.5px underline turns `#FF6218`.

**Transparency and blur.** Transparency is used arithmetically — every muted, faint, rule,
hairline, edge, wash and tint value is an alpha of ink, cream or orange. There is **no blur
anywhere**: no frosted glass, no backdrop-filter, no protection gradient behind text. Where
text needs separation from a photograph it gets a solid capsule or the mat, not a gradient.

**Imagery.** Monochrome, always, in both themes. Warm-neutral ground around it; the well is
near-black warm `#15130F` rather than pure black. No grain overlays, no duotones, no colour
washes.

**Layout rules.** One breakpoint. Nothing is fixed or sticky in the component set. Mono bars
wrap rather than truncate — the `margin-left:auto` that pushes the last item right becomes 0
below 900px so the row stacks. No horizontal scroll at any width, ever. Tap targets are 44px
minimum even where the mono label is 10px, and input values stay at 16px or more so phones
do not zoom on focus.

**Dark mode.** Ground and ink swap, driven by a `data-theme` attribute only, never by
`prefers-color-scheme`. Shadows off. Accent light `#FF8426` becomes the structural orange.
Paper is *darker* than ground so raised surfaces read as wells. The orange band is the one
element that does not invert.

## Iconography

**There is none, by design.** The specification is explicit: there is no emblem, icon,
symbol, monogram or arrow mark in this brand and there never will be. Nothing was drawn,
substituted from a CDN set, or approximated — no Lucide, no Heroicons, no icon font.

What stands in for iconography:

- **Unicode arrow `→`** inside directional text (`Read →`), coloured accent dark and always
  paired with a non-orange sibling label. This is text, not a mark.
- **Middot `·`** as the universal separator in eyebrows and mono bars.
- **Drawn rules**: the 26px eyebrow rule, the 2px accent left border, the four crop-mark
  corners. These are CSS borders, not assets.
- **No emoji**, ever.

The logo is a wordmark only, and no wordmark file was supplied — so "Emerging LA" is set in
Riegal 400 wherever a mark would go (see `thumbnail.html`).

## Using this system

Consumers link one file:

```html
<link rel="stylesheet" href="styles.css">
```

Then write `var(--ink)`, `var(--rule)`, `var(--accent)`, `var(--display-3)` and so on. Wrap
any block with a different ground in `.on-ink`, `.on-accent` or `.on-paper` rather than
overriding colours on its children. Switch themes with `data-theme="dark"` on a container.
